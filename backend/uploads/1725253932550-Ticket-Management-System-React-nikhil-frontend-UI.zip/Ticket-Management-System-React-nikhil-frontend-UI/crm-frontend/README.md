This project is part of a YouTube tutorial Create CRM ticket system with MERN stack from scratch to deploy to AWS
Here is the playlist https://youtube.com/playlist?list=PLtPNAX49WUFN8yq2vEuAY6AhM5EJOXQQ0

### Start project

`npm start`

If you need code before adding Redux in the project , clone from before-redux/toolkit

`git clone -b before-redux/toolkit git@github.com:DentedCode/crm-frontend.git`

### Backend API

Backend api for this app is in the following repo:
`https://github.com/DentedCode/client-api`
